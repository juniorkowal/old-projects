import numpy as np
from numpy.random import randint as rand
import matplotlib.pyplot as pyplot


# def maze(width, height, complexity=.75, density=.75):
#     # Adjust complexity and density relative to maze size
#     complexity = int(complexity * (5 * (width + height)))  # number of components
#     density = int(density * ((width // 2) * (height // 2)))  # size of components
#     # Build actual maze
#     z = hex_grid(height, width)
#     # Make aisles
#     for i in range(density):
#         x, y = rand(0, width // 2) * 2, rand(0, height // 2) * 2  # pick a random position
#         if y % 2 == 0:
#             x = 2 + x * 4
#             y = 3 + y * 4
#         else:
#             if x < width - 1:
#                 x = 4 + x * 4
#                 y = 3 + y * 4
#         # z[y, x] = 1
#         for j in range(complexity):
#             neighbours = []
#             if y % 2 == 0:
#                 if x > 0:
#                     neighbours.append((y, x - 1))
#                 if x < width - 1:
#                     neighbours.append((y, x + 1))
#                 if y > 0 and x > 0:
#                     neighbours.append((y - 1, x - 1))
#                 if y > 0 and x < width - 1:
#                     neighbours.append((y - 1, x + 1))
#                 if y < height - 1 and x > 0:
#                     neighbours.append((y + 1, x - 1))
#                 if y < height - 1 and x < width - 1:
#                     neighbours.append((y + 1, x + 1))
#             else:
#                 if x < width-1:
#                     if x > 0:
#                         neighbours.append((y, x - 1))
#                     if x < width - 2:
#                         neighbours.append((y, x + 1))
#                     neighbours.append((y - 1, x - 1))
#                     neighbours.append((y - 1, x + 1))
#                     neighbours.append((y + 1, x - 1))
#                     neighbours.append((y + 1, x + 1))
#             if len(neighbours):
#                 y_, x_ = neighbours[rand(0, len(neighbours) - 1)]
#                 if y % 2 == 0:
#                     wsp_x = 2 + x_ * 4
#                     wsp_y = 3 + y_ * 4
#                     if x-1 == x_ and y == y_:
#                     z[wsp_y, wsp_x + 2] = 0
#                     if x+1 == x_ and y == y_:
#                     z[wsp_y, wsp_x - 2] = 0
#                     if x-1 == x_ and y-1 == y_:
#
#                     if x-1 == x_ and y+1 == y_:
#
#                     if x+1 == x_ and y+1 == y_:
#
#                     if x+1 == x_ and y-1 == y_:
#                     z[wsp_y - 2, wsp_x + 1] = 0
#                 else:
#                     if x < width - 1:
#                         wsp_x = 4 + x * 4
#                         wsp_y = 3 + y * 4
#                         if x - 1 == x_ and y == y_:
#
#                         if x + 1 == x_ and y == y_:
#
#                         if x - 1 == x_ and y - 1 == y_:
#
#                         if x - 1 == x_ and y + 1 == y_:
#
#                         if x + 1 == x_ and y + 1 == y_:
#
#                         if x + 1 == x_ and y - 1 == y_:
#
#                 if z[y_, x_] == 1:
#                     z[y_, x_] = 0
#                     z[y_ + (y - y_) // 2, x_ + (x - x_) // 2] = 1
#                     x, y = x_, y_
#     return z


def hex_grid(wysokosc, szerokosc):
    grid = np.zeros(((wysokosc-1)*4+7, (szerokosc-1)*4+5), dtype=bool)
    for hex_y in range(wysokosc):
        for hex_x in range(szerokosc):
            if hex_y % 2 == 0:
                x = 2+hex_x*4
                y = 3 + hex_y * 4
                grid[y, x - 2] = 1
                grid[y - 1, x - 2] = 1
                grid[y - 2, x - 1] = 0
                grid[y - 3, x] = 1
                grid[y - 2, x + 1] = 1
                grid[y - 1, x + 2] = 1
                grid[y, x + 2] = 1
                grid[y + 1, x + 2] = 1
                grid[y + 2, x + 1] = 1
                grid[y + 3, x] = 1
                grid[y + 2, x - 1] = 1
                grid[y + 1, x - 2] = 1
            else:
                if hex_x < szerokosc-1:
                    x = 4+hex_x*4
                    y = 3 + hex_y * 4
                    grid[y, x - 2] = 1
                    grid[y - 1, x - 2] = 1
                    grid[y - 2, x - 1] = 1
                    grid[y - 3, x] = 1
                    grid[y - 2, x + 1] = 1
                    grid[y - 1, x + 2] = 1
                    grid[y, x + 2] = 1
                    grid[y + 1, x + 2] = 1
                    grid[y + 2, x + 1] = 1
                    grid[y + 3, x] = 1
                    grid[y + 2, x - 1] = 1
                    grid[y + 1, x - 2] = 1
    return grid


pyplot.imshow(hex_grid(10, 10), cmap=pyplot.cm.binary, interpolation='nearest')
pyplot.xticks([]), pyplot.yticks([])
pyplot.show()
