from multiprocessing import Process
import os
import pyaudio
import cv2
import wave
import keyboard

def video_capture():
    video = cv2.VideoCapture(0)

    if (video.isOpened() == False): 
        print("error video")
    
    frame_width = int(video.get(3))
    frame_height = int(video.get(4))
    
    size = (frame_width, frame_height)
    
    result = cv2.VideoWriter('filename.avi', cv2.VideoWriter_fourcc(*'MJPG'),24, size)
        
    while True:
        ret, frame = video.read()
    
        if ret == True: 
            result.write(frame)
            cv2.imshow('Frame', frame)
            key=cv2.waitKey(1)

            if key==27: break
        else: break
    
    video.release()
    result.release()
        
    cv2.destroyAllWindows()


def sound_capture():
    format = pyaudio.paInt16
    p = pyaudio.PyAudio()

    stream = p.open(format=format,channels=1,rate=44100,output=True,input=True,frames_per_buffer=1024)

    stream.start_stream()
    audio=[]

    while True:
        
        if keyboard.is_pressed("esc"):
            break

        data = stream.read(1024)
        audio.append(data)

    stream.stop_stream()
    stream.close()
    p.terminate()

    waveFile = wave.open('dzwiek.wav', 'wb')
    waveFile.setnchannels(1)
    waveFile.setsampwidth(p.get_sample_size(format))
    waveFile.setframerate(44100)
    waveFile.writeframes(b''.join(audio))
    waveFile.close()

#video_capture()
#sound_capture()

if __name__ == "__main__":
    p1=Process(target=sound_capture)
    p2=Process(target=video_capture,args=())
    p1.start()
    p2.start()
    p1.join()
    p2.join()