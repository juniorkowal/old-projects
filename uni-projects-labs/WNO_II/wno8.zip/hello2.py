from flask import Flask, render_template, request, url_for, flash, redirect
import random as rn

app = Flask(__name__)

app.config['SECRET_KEY'] = 'dev'

color = {
        'yellow': 'e1eb34',
        'green': '28fc03',
        'pink': 'FF95AE',}

@app.route('/', methods=('GET', 'POST'))
def wordle():
    words_list=words()
    #chosen_word=words_list[rn.randrange(0,len(words_list))]
    chosen_word='blind'
    print(chosen_word)
    if request.method == 'POST':

        l1=request.form['l1']
        l2=request.form['l2']
        l3=request.form['l3']
        l4=request.form['l4']
        l5=request.form['l5']
        wordsy=[]
        first_word=False

        if not l1 or not l2 or not l3 or not l4 or not l5:
            flash('PROSZĘ UZUPEŁNIĆ WSZYSTKIE POLA')
        else:
            first_word=True
            word1=l1+l2+l3+l4+l5
            word1=word1.lower()
            word_in_list = [word for word in words_list if word1 == word]
            if word_in_list:
                if word1==chosen_word:
                    flash('WYGRANA')
                    return render_template('wordle2.html',letters1='28fc03',first_word=first_word)
                else:
                    colors={}

                    for i in range(len(chosen_word)):
                        color="l"+str(i+1)
                        if word1[i] in chosen_word and word1[i] is chosen_word[i]:
                            colors[color]="28fc03" #zielone
                        else:
                            colors[color]="FFFFFF"
                    print(colors)
                    l6=request.form['l6']
                    l7=request.form['l7']
                    l8=request.form['l8']
                    l9=request.form['l9']
                    l10=request.form['l10']
                    if not l6 or not l7 or not l8 or not l9 or not l10:
                        flash('PROSZĘ UZUPEŁNIĆ WSZYSTKIE POLA')
                    else:
                        word2=l6+l7+l8+l9+l10
                        word2=word2.lower()
                        word_in_list = [word for word in words_list if word2 == word]
                        if word_in_list:
                            if word2==chosen_word:
                                flash('WYGRANA')
                                return render_template('wordle2.html',colors=colors,letters2='28fc03',first_word=first_word)
                            else:
                                colors2={}
                                for i in range(len(chosen_word)):
                                    color="l"+str(i+6)
                                    if word2[i] in chosen_word and word2[i] is chosen_word[i]:
                                        colors2[color]="28fc03"
                                    else:
                                        colors2[color]="FFFFFF"
                                wordsy.append(word1)
                                wordsy.append(word2)
                                wordsy.append(chosen_word)
                                wordsy=sorted(wordsy)
                                
                                wyswietl=''
                                for i in range(len(wordsy)):
                                    if wordsy[i]==chosen_word:
                                        wyswietl=wyswietl+'* '
                                    else:    
                                        wyswietl=wyswietl+wordsy[i]+' '
                                


                                flash(wyswietl)
                                return render_template('wordle2.html',colors=colors,colors2=colors2,first_word=first_word)
                            #tutaj nowe dac
                    return render_template('wordle2.html',colors=colors,first_word=first_word)

        print(first_word)
        if first_word:
            l6=request.form['l6']
            l7=request.form['l7']
            l8=request.form['l8']
            l9=request.form['l9']
            l10=request.form['l10']
            print(l6)
            if not l6 or not l7 or not l8 or not l9 or not l10:
                flash('PROSZĘ UZUPEŁNIĆ WSZYSTKIE POLA')
            else:
                word2=l6+l7+l8+l9+l10
                word2=word2.lower()
                word_in_list = [word for word in words_list if word2 == word]
                if word_in_list:
                    if word2==chosen_word:
                        print('znaleziono slowo gratki')
                        flash('WYGRANA')
                        return render_template('wordle.html',letters2='28fc03',first_word=first_word)
                    else:
                        colors2={}
                        for i in range(len(chosen_word)):
                            color="l"+str(i+6)
                            if word2[i] in chosen_word and word2[i] is chosen_word[i]:
                                print('zielone: '+word2[i])
                                colors2[color]="28fc03"
                            elif word2[i] in chosen_word:
                                print('żółte '+word2[i])
                                colors2[color]="e1eb34"
                            else:
                                colors2[color]="FFFFFF"
                        print(colors2)
                        return render_template('wordle2.html',colors2=colors2,first_word=first_word)




    return render_template('wordle2.html')


def words():
    w=[]
    with open('words_eng.txt', 'r') as f:
        for line in f.readlines():
            w.append(line.rstrip().lower())
    return w


# words_list=words()
# chosen_word=words_list[rn.randrange(0,len(words_list))]
# word1='board'
# word_in_list = [word for word in words_list if word1 == word]
# print(word_in_list[0])
# if word_in_list[0]:
#     print('ta')
# word1='droab'

# for i in range(len(chosen_word)):
#     if word1[i] in chosen_word and word1[i] is chosen_word[i]:
#         print('zielone: '+word1[i])
#     elif word1[i] in chosen_word:
#         print('żółte '+word1[i])


if __name__=='__main__':
   app.run()
