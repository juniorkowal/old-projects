import smtplib
import imaplib


USER="miejscenamila"
PASSWORD="miejscenahaslo"

def send_mail():

    recipients=["frfr3000@yahoo.com"]
    title='test'
    text='its not possible'

    email_text="""\
    From: %s
    To: %s
    Subject: %s

    %s
    """ % (USER, ", ".join(recipients),title,text)

    try:
        smtp_server = smtplib.SMTP_SSL('smtp.mail.yahoo.com',465)
        smtp_server.set_debuglevel(1)
        smtp_server.ehlo()
        smtp_server.login(USER,PASSWORD)
        smtp_server.sendmail(USER,recipients,email_text)
        smtp_server.close()
        print ("Email wyslany!")
    except Exception as e:
        print ("Blad... : ",e)


def get_mail():

    imap_server='imap.mail.yahoo.com'

    imap=imaplib.IMAP4_SSL(imap_server)
    imap.login(USER, PASSWORD)
    _,messages=imap.select("INBOX")

    _,messages=imap.search(None, 'ALL')

    message_to_sth=[]

    for num in messages[0].split():
        _, data = imap.fetch(num, '(RFC822)')
        message_to_sth.append(data[0][1].decode('utf-8'))

    msg_whole=[]
    messages=[]

    substrings=['From: ','Date: ','Subject: ','To: ','div']
    for msg in message_to_sth:
        #print(msg)
        for line in msg.splitlines():
            for x in substrings:
                if x in line:
                    msg_whole.append(line)
        msg_whole.pop(0)           
        messages.append(msg_whole)
        msg_whole=[]

    print(messages)

    imap.close()
    imap.logout()


if __name__ == '__main__':
    send_mail()
    #get_mail()