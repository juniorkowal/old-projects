from multiprocessing import Process,Pool,Manager, process, cpu_count, Array
import random
import cv2 as cv
import numpy as np
import glob
import os
import math
from numba import jit
import timeit
import time
import csv
import re
from natsort import natsorted



def paths(path):
    paths = [os.path.join(path, image) for image in os.listdir(path)]
    return paths


def images_list(path,img_list):
    img_list.append(cv.imread(path))


def images_gray(images):
    images=[(0.07*img[:,:,2]+0.72*img[:,:,1]+0.21*img[:,:,0]).astype(np.uint8) for img in images]
    return images


def images_blend(images):
    empty=np.zeros_like(images[0])
    empty_copy=empty.copy()

    for img in images:
        empty=empty+img/140
    blend=empty.astype(np.uint8)

    _, dst = cv.threshold(blend, 180, 255, cv.THRESH_BINARY)

    pts = np.array([[364,96],[1367,296],[1731,837],[1663,880],[1428,935],[1151,962],[1151,962],[783,915],[480,823],[350,741]])

    mask_shape = cv.fillPoly(empty_copy,[pts],(255,))
    masked_image = cv.bitwise_and(dst, mask_shape)

    opening = cv.morphologyEx(masked_image, cv.MORPH_OPEN, (3,3))

    contours, _ = cv.findContours(opening, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)

    empty_copy=np.zeros_like(images[0])

    coordinates=[]
    var=30
    for con in contours:
        x,y,w,h=cv.boundingRect(con)
        coordinates.append((x-var,y-var,w+var,h+var))
        cv.rectangle(empty_copy,(x-var,y-var),(x+w+var,y+h+var),(255,255,255),-1)

    return empty_copy, coordinates
        

def detect_candy(imgs,g_imgs,mask,coords):
    amount=[]

    for i in range(len(imgs)):
        empty=np.zeros_like(imgs[0])
        mask_3d = np.stack((mask,mask,mask),axis=2)
        mask_normal = cv.bitwise_and(imgs[i], mask_3d)
        mask_gray = cv.bitwise_and(g_imgs[i], mask)
        _, dst = cv.threshold(mask_gray, 180, 255, cv.THRESH_BINARY)
        dst = cv.morphologyEx(dst, cv.MORPH_OPEN, (30,30))

        contours, _ = cv.findContours(dst, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
        contours_area=[]
        for con in contours:
            area = cv.contourArea(con)
            #print(area)
            if area>7500:
                contours_area.append(con)
                
        dst=cv.drawContours(empty, contours_area, -1, (255,255,255), -1)

        candies_detected=0
        # cv.imshow("img", dst)
        # cv.waitKey()
        var=10
        for c in coords:
            x,y,w,h=c[0],c[1],c[2],c[3]
            #print(x,y,w,h)
            candy=dst[y:y+h+var,x:x+w+3*var]

            candy_crop=candy.copy()
            candy_crop=candy_crop[:, :, 0]
            #print(candy_crop.shape,candy_crop.dtype)
            small_contours,_=cv.findContours(candy_crop, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
            circularity=0
            if small_contours:
                c = max(small_contours, key = cv.contourArea)

                x,y,w,h=cv.boundingRect(c)
                candy=candy_crop[y:y+h,x:x+w]

                perimeter = cv.arcLength(c, True)
                area = cv.contourArea(c)
                if perimeter == 0:
                    perimeter=0.01
                circularity = 4*math.pi*(area/(perimeter*perimeter))
            #print(circularity)
            #cv.imshow("img", candy)
            #cv.waitKey()    
            candy=candy/255
            candy=candy.flatten()
            candy_true=np.sum(candy)
            #print(candy_true)
            #print(circularity)
            #print(candy_true/(len(candy)))
            if candy_true/(len(candy))>0.6 or 0.5<circularity<1:
                candies_detected+=1
                #print('tak!')

                #print(candy_true/(len(candy)))
            #cv.imshow("img", candy_crop)
            #cv.waitKey()           
        amount.append(candies_detected)

    return amount

def wczytaj(sciezki):
    obrazy = []
    for path in sciezki:
        obrazy.append(cv.imread(path))
        #print(path)
    return obrazy


def compare(candies):
    noise_amp=[]
    with open('cukierki.csv', 'r') as rf:
        reader = csv.reader(rf, delimiter=',')
        for row in reader:
            noise_amp.append(row[1])
    
    correct=0
    for i in range(len(candies)):
        if noise_amp[i]==str(candies[i]):
            correct+=1

    print(correct/1.4)


def num_sort(test_string):
    return list(map(int, re.findall(r'\d+', test_string)))[0]

if __name__ == "__main__":

    # manager=Manager()
    # img_list = manager.list()

    # processes = cpu_count()
    img_paths=paths('images')
    img_paths=natsorted(img_paths)
    # pool=Pool(processes)

    # [pool.apply_async(images_list, args=[img_paths,img_list]) for img_paths in img_paths]
    # pool.close()
    # pool.join()

    # img_list = list(img_list)
    
    #img_paths=natsorted(img_paths)

    img_list=wczytaj(img_paths)

    gray_list=images_gray(img_list)
    candy_mask,coordinates=images_blend(gray_list)

    z=detect_candy(img_list,gray_list,candy_mask,coordinates)
    print(len(z))
    print(z)

    compare(z)

    # cv.imshow("img", candy_mask)
    # cv.waitKey()










#imgs=np.array(imgs)


# starttime = timeit.default_timer()
# imgs=wczytaj()
# print("The time difference is :", timeit.default_timer() - starttime)

