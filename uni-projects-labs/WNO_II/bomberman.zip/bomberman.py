import sys
from main_window import Ui_MainWindow
from PySide2.QtWidgets import (
    QGraphicsItem,
    QPushButton,
    QGraphicsScene,
    QWidget,
    QVBoxLayout,
    QMainWindow,
    QApplication,
    QGraphicsView,
    QGraphicsProxyWidget
)
from PySide2.QtCore import Qt
from PySide2.QtCore import QTimer
from PySide2.QtCore import QPropertyAnimation, QThread, Signal
from PySide2.QtGui import QPainterPath, QColor, QBrush
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

# class Agent:
#     def __init__(self,x=1,y=1):
#         self.x=x
#         self.y=y

# class Field:
#     def __init__(self,type):
#         self.type=type

#     def __repr__(self):
#         if self.type=='obstacle':
#             return '█'
#         elif self.type=='destructible':
#             return '█'
#         elif self.type=='agent':
#             return '█'
#         else:
#             return ' '

# class Plansza:
#     def __init__(self):
#         self.plansza = [ [0]*120 for i in range(120)]
#         clearConsole()
#         self.wypelnij()
#         self.agent=Agent(1,1)
#         self.graczUpdate()
#         self.pokazplansze()
#         #self.ruszanie()

#     def wypelnij(self):
#         for i in range(120):
#             for j in range(120):
#                 if i==0 or i==119 or j==0 or j==119 or j%2==0 and i%2==0:
#                     self.plansza[i][j]=Field('obstacle')
#                 else:
#                     self.plansza[i][j]=Field('none')

#     def pokazplansze(self):
#         print('\n'.join(' '.join(map(str, sub)) for sub in (self.plansza)))

#     def graczUpdate(self):
#         self.plansza[self.agent.x][self.agent.y].type='agent'

#     def ruszanie(self):
#         while True:
#             ruch_bytes=getch()
#             ruch=ruch_bytes.decode(encoding='utf-8',errors='ignore').lower()

#             dir_ver=0
#             dir_hor=0

#             if ruch in 'wasd':
#                 move=True
#             else:
#                 move=False

#             if ruch=='d':
#                 dir_hor=1
#                 dir_ver=0
#             elif ruch=='a':
#                 dir_hor=-1
#                 dir_ver=0
#             elif ruch=='w':
#                 dir_ver=-1
#                 dir_hor=0
#             elif ruch=='s':
#                 dir_ver=1
#                 dir_hor=0
            
#             if self.plansza[self.agent.x+dir_ver][self.agent.y+dir_hor].type!='obstacle' and move:
#                 self.plansza[self.agent.x+dir_ver][self.agent.y+dir_hor].type='agent'
#                 self.plansza[self.agent.x][self.agent.y].type='none'
#                 self.agent.y+=dir_hor
#                 self.agent.x+=dir_ver
#                 clearConsole()
#                 self.pokazplansze()

#             if ruch_bytes==b'\x1b':
#                 break


class Window(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

        self.fps_timer=QTimer(self)
        self.fps_timer.timeout.connect(self.test)
        self.fps_timer.start(1000/33)

        #self.centralwidget.add_widgets()
        #self.test()

    def test(self):
        self.centralwidget.add_widgets()

    









if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = Window()
    win.show()
    sys.exit(app.exec_())