from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
import random #testy
        # gray='#737373'
        # green='#33cc33'
        # blue='#0066ff'

class GraphicsItem(QGraphicsItem):
    def __init__(self,color,i,j):
        super().__init__()

        self.color=color
        self.item_body = self.draw_item(i,j)


    def draw_item(self,i,j):
        path = QPainterPath()
        path.addRect(i*48,j*47,48,47)
        return path

    def paint(self, painter, option, widget):
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(f"{self.color}")))
        painter.drawPath(self.item_body)

    def boundingRect(self):
        return self.item_body.boundingRect()


# class Agent(GraphicsItem):
#     def __init__(self,color,i,j):
#         super().__init__(color,i,j)


class MainWidgets(QWidget):
    def __init__(self):
        super().__init__()

        self.scene = QGraphicsScene()
        self.view = QGraphicsView(self.scene)

        gray='#737373'
        green='#33cc33'
        blue='#0066ff'
        self.colors=[gray,green,blue]

        _layout = QVBoxLayout()
        _layout.addWidget(self.view)

        self.setLayout(_layout)

        #nwm='cos'

        #self.add_widgets(nwm)

    def add_widgets(self):
        self.scene.clear()
        for i in range(12):
            for j in range(8):
                color=random.choice(self.colors)
                self.scene.addItem(GraphicsItem(color,i,j))
                


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1080, 720)
        self.centralwidget = MainWidgets()
        self.centralwidget.setFixedSize(600,400)
        self.centralwidget.setObjectName(u"centralwidget")
        MainWindow.setCentralWidget(self.centralwidget)
        self.leftdock = QDockWidget(MainWindow)
        self.leftdock.setObjectName(u"leftdock")
        self.leftdock.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.leftdock.setAllowedAreas(Qt.LeftDockWidgetArea)
        self.leftwidget = QWidget()
        self.leftwidget.setObjectName(u"leftwidget")
        self.leftwidget.setEnabled(True)
        self.leftdock.setWidget(self.leftwidget)
        MainWindow.addDockWidget(Qt.LeftDockWidgetArea, self.leftdock)
        self.rightdock = QDockWidget(MainWindow)
        self.rightdock.setObjectName(u"rightdock")
        self.rightdock.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.rightdock.setAllowedAreas(Qt.BottomDockWidgetArea|Qt.RightDockWidgetArea)
        self.rightwidget = QWidget()
        self.rightwidget.setObjectName(u"rightwidget")
        self.rightdock.setWidget(self.rightwidget)
        self.logger = QTextEdit(self.rightwidget)
        self.logger.setObjectName(u"logger")
        self.logger.setGeometry(QRect(0, 0, 231, 421))  
        self.logger.setReadOnly(True)      
        MainWindow.addDockWidget(Qt.RightDockWidgetArea, self.rightdock)
        self.bottomdock = QDockWidget(MainWindow)
        self.bottomdock.setObjectName(u"bottomdock")
        self.bottomdock.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.bottomdock.setAllowedAreas(Qt.BottomDockWidgetArea)
        self.bottomwidget = QWidget()
        self.bottomwidget.setObjectName(u"bottomwidget")
        self.up_arrow = QToolButton(self.bottomwidget)
        self.up_arrow.setObjectName(u"up_arrow")
        self.up_arrow.setGeometry(QRect(500, 10, 80, 80))
        self.up_arrow.setArrowType(Qt.UpArrow)
        self.down_arrow = QToolButton(self.bottomwidget)
        self.down_arrow.setObjectName(u"down_arrow")
        self.down_arrow.setGeometry(QRect(500, 110, 80, 80))
        self.down_arrow.setArrowType(Qt.DownArrow)
        self.left_arrow = QToolButton(self.bottomwidget)
        self.left_arrow.setObjectName(u"left_arrow")
        self.left_arrow.setGeometry(QRect(400, 110, 80, 80))
        self.left_arrow.setArrowType(Qt.LeftArrow)
        self.right_arrow = QToolButton(self.bottomwidget)
        self.right_arrow.setObjectName(u"right_arrow")
        self.right_arrow.setGeometry(QRect(600, 110, 80, 80))
        self.right_arrow.setArrowType(Qt.RightArrow)
        self.bottomdock.setWidget(self.bottomwidget)
        MainWindow.addDockWidget(Qt.BottomDockWidgetArea, self.bottomdock)

        self.rightdock.setFixedWidth(240)
        self.leftdock.setFixedWidth(240)
        self.bottomdock.setFixedHeight(240)

        self.rightdock.setStyleSheet("QDockWidget::title { border: 0px}")
        self.leftdock.setStyleSheet("QDockWidget::title { border: 0px}")
        self.bottomdock.setStyleSheet("QDockWidget::title { border: 0px}")

        self.up_arrow.setStyleSheet("QToolButton { border: 1px solid #8f8f91;background-color: white;} QToolButton:pressed { background-color: lightgray;}")
        self.down_arrow.setStyleSheet("QToolButton { border: 1px solid #8f8f91;background-color: white;} QToolButton:pressed { background-color: lightgray;}")
        self.left_arrow.setStyleSheet("QToolButton { border: 1px solid #8f8f91;background-color: white;} QToolButton:pressed { background-color: lightgray;}")
        self.right_arrow.setStyleSheet("QToolButton { border: 1px solid #8f8f91;background-color: white;} QToolButton:pressed { background-color: lightgray;}")


        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.up_arrow.setText(QCoreApplication.translate("MainWindow", u"...", None))
        self.down_arrow.setText(QCoreApplication.translate("MainWindow", u"...", None))
        self.left_arrow.setText(QCoreApplication.translate("MainWindow", u"...", None))
        self.right_arrow.setText(QCoreApplication.translate("MainWindow", u"...", None))
        self.logger.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Logger", None))
    # retranslateUi

