# tetris o planszy 15x25
# kształty:     #    # # #     #
#               #    #####    ###
# sterowanie: kształty musza sie tez obracac
import numpy as np
import pygame
import random

from sympy import li

# Mateusz Comblik 175827
# Zrealizowane punkty: umieszczanie bloków, nienachodzących na siebie (1 pkt)
# Podświetlanie aktywnego bloku

pygame.init()

window = pygame.display.set_mode((376 ,626))

for i in range(0, 900, 25):
    pygame.draw.line(window, (255, 255, 255), (0, i), (900, i))
    pygame.draw.line(window, (255, 255, 255), (i, 0), (i, 900))
pygame.display.update()

pola_gry = [[0 for i in range(15)] for j in range(25)]

ksztalt_i=[[1],[1],[1]]
ksztalt_t=[[0,1,0],[1,1,1]]
ksztalt_grzebien=[[1,0,1,0,1],[1,1,1,1,1]]

kolory_ksztaltow = [(255,0,0),(0,255,0),(0,0,255),(255,255,0)]
typy_ksztaltow=['I','T','W']

class Ksztalt(object):
    def __init__(self, typ, kolumna, wiersz):
        if typ=='I':
            self.typ=ksztalt_i
        elif typ=='T':
            self.typ=ksztalt_t
        else:
            self.typ=ksztalt_grzebien
        self.x=kolumna
        self.y=wiersz
        self.nr_ksztaltu = typy_ksztaltow.index(typ)
        self.narysowany=False
        self.kolor = kolory_ksztaltow[typy_ksztaltow.index(typ)]

lista_blokow=[]

def rysuj_pole(x,y,kolor):
    pygame.draw.rect(window, kolor, pygame.Rect(25*x+1, 25*y+1, 24, 24))
    pygame.display.update()

for i in range(12):
    lista_blokow.append(Ksztalt(random.choice(typy_ksztaltow),random.randint(0,10),random.randint(0,20)))
    #print(lista_blokow[i].typ)

def rysuj_plansze():
    for i in range(15):
        for j in range(25):
            for blok in lista_blokow:
                if blok.x==i and blok.y==j:

                    if blok.nr_ksztaltu==0:
                        if pola_gry[j][i] or pola_gry[j+1][i] or pola_gry[j+2][i]:
                            blok.x=random.randint(0,10)
                            blok.y=random.randint(0,20)
                            rysuj_plansze()
                        elif not blok.narysowany:
                            rysuj_blok(blok,0,i,j)
                            blok.srodek=(blok.x,blok.y)
                            blok.narysowany=True

                    elif blok.nr_ksztaltu==1:
                        if pola_gry[j][i+1] or pola_gry[j+1][i] or pola_gry[j+1][i+1] or pola_gry[j+1][i+2]:
                            blok.x=random.randint(0,10)
                            blok.y=random.randint(0,20)
                            rysuj_plansze()
                        elif not blok.narysowany:
                            rysuj_blok(blok,1,i,j)
                            blok.srodek=(blok.x,blok.y)
                            blok.narysowany=True

                    elif blok.nr_ksztaltu==2:
                        if pola_gry[j][i] or pola_gry[j][i+2] or pola_gry[j][i+4] or pola_gry[j+1][i] or pola_gry[j+1][i+1] or pola_gry[j+1][i+2] or pola_gry[j+1][i+3] or pola_gry[j+1][i+4]:
                            blok.x=random.randint(0,10)
                            blok.y=random.randint(0,20)
                            rysuj_plansze()
                        elif not blok.narysowany:
                            rysuj_blok(blok,2,i,j)
                            blok.srodek=(blok.x,blok.y)
                            blok.narysowany=True                            

def rysuj_blok(blok,nr_koloru,i,j):
    for l in range(len(blok.typ)):
        for m in range(len(blok.typ[l])):
            pola_gry[l+j][m+i]=blok.typ[l][m]
            if blok.typ[l][m]==1:
                rysuj_pole(m+i,l+j,kolory_ksztaltow[nr_koloru])

rysuj_plansze()

for j in range(25):
    print(pola_gry[j])

pygame.display.set_caption('Tetris')

petla_gry = True
poprzedni=11
licznik=0

def wybierz_aktywny(licznik,poprzedni):
    global aktualny_blok
    aktualny_blok=lista_blokow[licznik]
    poprzedni_blok=lista_blokow[poprzedni]
    rysuj_blok(aktualny_blok,3,aktualny_blok.srodek[0],aktualny_blok.srodek[1])
    rysuj_blok(poprzedni_blok,kolory_ksztaltow.index(poprzedni_blok.kolor),poprzedni_blok.srodek[0],poprzedni_blok.srodek[1])

wybierz_aktywny(licznik,poprzedni )

while petla_gry:
    rysuj_plansze()
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            petla_gry = False
            pygame.display.quit()
            quit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE: 
                licznik+=1
                poprzedni=licznik-1
                if licznik>11:
                    licznik=0
                    poprzedni=11
                elif licznik<0:
                    licznik=11
                    poprzedni=0
                wybierz_aktywny(licznik,poprzedni)
